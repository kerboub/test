<?php

/************************** Custom Template *****************************/

return array(
	'name'              => esc_attr__( 'Process Style 1', 'boldman' ),    // Template Title
	'template_category' => esc_attr__( 'Process', 'boldman' ),	 // Template Category
	// 'new'            => true,                                 // Enable to display New badge.
	'content'           => '<<<TMCONTENTTILLTHIS
[vc_row tm_bgimagefixed="" break_in_responsive="1200" full_width="stretch_row" tm_responsive_css="86892882|colbreak_no|||||||||colbreak_no|||||40px||25px||colbreak_no||||||||||colbreak_no|||||||||" css=".vc_custom_1550046736041{padding-bottom: 90px !important;}"][vc_column][vc_row_inner][vc_column_inner][tm-processbox h2="Follow 4 Easy Steps" h4="HOW IT WORKS" txt_align="center" reverse_heading="true" boximg_size="210x210" box_content="%5B%7B%22static_boximage%22%3A%223632%22%2C%22static_boxtitle%22%3A%22Schedule%20your%20Experience%22%2C%22static_boxcontent%22%3A%22He%20found%20himself%20transformed%20in%20his%20bed%20into%20a%20horrible%20vermin.%22%7D%2C%7B%22static_boximage%22%3A%223632%22%2C%22static_boxtitle%22%3A%22Get%20Professional%20Advices%22%2C%22static_boxcontent%22%3A%22He%20found%20himself%20transformed%20in%20his%20bed%20into%20a%20horrible%20vermin.%22%7D%2C%7B%22static_boximage%22%3A%223632%22%2C%22static_boxtitle%22%3A%22Meet%20Your%20Handyman%20Expert%22%2C%22static_boxcontent%22%3A%22He%20found%20himself%20transformed%20in%20his%20bed%20into%20a%20horrible%20vermin.%22%7D%2C%7B%22static_boximage%22%3A%223632%22%2C%22static_boxtitle%22%3A%22Get%20a%20Best%20Our%20Services%20At%20Door%22%2C%22static_boxcontent%22%3A%22He%20found%20himself%20transformed%20in%20his%20bed%20into%20a%20horrible%20vermin.%22%7D%5D"]Raising a heavy fur muff that covered the whole of her lower arm towards the viewer regor then turned to look out the window[/tm-processbox][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
TMCONTENTTILLTHIS',
);
